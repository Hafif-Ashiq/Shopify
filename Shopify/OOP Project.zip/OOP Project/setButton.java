import javax.swing.*;
public interface setButton {
    public JButton setButton(int button_x, int button_y, int buttonWidth, int buttonHeight, String buttonText, String fontLocation, float fontSize);
}
