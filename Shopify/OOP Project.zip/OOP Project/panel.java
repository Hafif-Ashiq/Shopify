import javax.swing.*;
public interface panel {
    public void panels(JFrame frame, int x_axis, int y_axis, int width, int height, int R, int G, int B);
    
}


