import java.awt.*;
public interface font {
    
    public Font newFont(String fontLocation, Float fontSize);

}
