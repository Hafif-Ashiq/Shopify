import javax.swing.*;
public interface panelWithLabel{
    public void panels(JFrame frame, int x_axis, int y_axis, int width, int height, int R, int G, int B, String text, String fontLocation, float fontSize);
}
